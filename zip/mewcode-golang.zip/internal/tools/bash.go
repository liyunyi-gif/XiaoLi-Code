// 来源：公众号@小林coding
// 后端八股网站：xiaolincoding.com
// Agent网站：xiaolinnote.com
// 简历模版：jianli.xiaolinnote.com

package tools

import (
	"bytes"
	"context"
	"fmt"
	"os/exec"
	"path/filepath"
	"strings"
	"time"
)

// commandErrorThresholds 定义特殊命令的退出码阈值，
// 退出码 >= 阈值才视为真正的错误。
// 例如 grep 退出码 1 表示"没有匹配"，不算错误；退出码 2 才是语法/IO 错误。
var commandErrorThresholds = map[string]int{
	"grep": 2, // exit 1 = 无匹配
	"rg":   2, // ripgrep，同 grep
	"diff": 2, // exit 1 = 文件有差异
	"find": 2, // exit 1 = 部分成功（权限不足等）
	"test": 2, // exit 1 = 条件为假
	"[":    2, // test 的别名写法
}

// interpretExitCode 根据命令语义判断退出码是否代表错误。
// 管道场景取最后一个命令（bash 默认以最后一条的退出码作为管道退出码）。
func interpretExitCode(command string, exitCode int) bool {
	if exitCode == 0 {
		return false
	}
	base := extractLastCommand(command)
	if threshold, ok := commandErrorThresholds[base]; ok {
		return exitCode >= threshold
	}
	// 默认：非零即错误
	return true
}

// extractLastCommand 从完整命令字符串中提取管道最后一段的基础命令名。
// 例如 "cat file | grep foo" → "grep"，"timeout 5 rg pattern" → "rg"。
func extractLastCommand(command string) string {
	// 取管道最后一段
	parts := strings.Split(command, "|")
	last := strings.TrimSpace(parts[len(parts)-1])
	if last == "" {
		return ""
	}
	// 取第一个 token 作为命令，再去掉路径前缀
	fields := strings.Fields(last)
	if len(fields) == 0 {
		return ""
	}
	return filepath.Base(fields[0])
}

const maxTimeout = 600

type BashTool struct{}

func (t *BashTool) Name() string            { return "Bash" }

func (t *BashTool) Description() string     { return BashDescription }

func (t *BashTool) Category() ToolCategory  { return CategoryCommand }

func (t *BashTool) Schema() map[string]any {
	return map[string]any{
		"name":        t.Name(),
		"description": t.Description(),
		"input_schema": map[string]any{
			"type": "object",
			"properties": map[string]any{
				"command": map[string]any{"type": "string", "description": "Shell command to execute"},
				"timeout": map[string]any{"type": "integer", "description": "Timeout in seconds (max 600)", "default": 120},
			},
			"required": []string{"command"},
		},
	}
}

func (t *BashTool) Execute(ctx context.Context, args map[string]any) ToolResult {
	command, _ := args["command"].(string)
	if command == "" {
		return ToolResult{Output: "Error: command is required", IsError: true}
	}

	timeout := intArg(args, "timeout", 120)
	if timeout > maxTimeout {
		timeout = maxTimeout
	}

	ctx, cancel := context.WithTimeout(ctx, time.Duration(timeout)*time.Second)
	defer cancel()

	cmd := exec.CommandContext(ctx, "bash", "-c", command)
	var stdout, stderr bytes.Buffer
	cmd.Stdout = &stdout
	cmd.Stderr = &stderr

	err := cmd.Run()

	if ctx.Err() == context.DeadlineExceeded {
		return ToolResult{Output: fmt.Sprintf("Error: command timed out after %ds", timeout), IsError: true}
	}

	exitCode := 0
	isError := false
	if err != nil {
		if exitErr, ok := err.(*exec.ExitError); ok {
			exitCode = exitErr.ExitCode()
			// 根据命令语义判断退出码是否为真正的错误
			isError = interpretExitCode(command, exitCode)
		} else if ctx.Err() == nil {
			return ToolResult{Output: fmt.Sprintf("Error executing command: %s", err), IsError: true}
		}
	}

	var sb bytes.Buffer
	fmt.Fprintf(&sb, "$ %s\n", command)
	if stdout.Len() > 0 {
		sb.Write(stdout.Bytes())
		if stdout.Bytes()[stdout.Len()-1] != '\n' {
			sb.WriteByte('\n')
		}
	}
	if stderr.Len() > 0 {
		fmt.Fprintf(&sb, "STDERR: %s", stderr.String())
		if stderr.Bytes()[stderr.Len()-1] != '\n' {
			sb.WriteByte('\n')
		}
	}
	fmt.Fprintf(&sb, "(exit code %d)", exitCode)

	return ToolResult{Output: sb.String(), IsError: isError}
}
