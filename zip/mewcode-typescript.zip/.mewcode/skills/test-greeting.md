---
name: test-greeting
description: A test skill that greets the user
mode: inline
---

Greet the user warmly. If a name is provided in the arguments, use that name in the greeting. Say "Welcome to MewCode, {name}!" and offer to help with their coding tasks.
