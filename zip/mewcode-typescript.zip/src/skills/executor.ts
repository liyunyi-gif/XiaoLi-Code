// 来源：公众号@小林coding
// 后端八股网站：xiaolincoding.com
// Agent网站：xiaolinnote.com
// 简历模版：jianli.xiaolinnote.com

import type { Skill, SkillHost, SkillForkHost } from "./skill.js";

/**
 * 快速失败依赖检查：验证 skill 声明的 allowedTools 是否都已注册。
 * 如果有未注册的工具，抛出错误而非让模型在执行过程中才发现。
 * 对齐 Go 版 assertAllowedToolsExist。
 */
function assertAllowedToolsExist(skill: Skill, host: SkillHost): void {
  if (!skill.meta.allowedTools || skill.meta.allowedTools.length === 0) return;

  const registry = host.toolRegistry();
  for (const toolName of skill.meta.allowedTools) {
    if (!registry.get(toolName)) {
      throw new Error(
        `skill "${skill.meta.name}" declares allowed tool "${toolName}" which is not registered`
      );
    }
  }
}

/**
 * 以 inline 模式运行 skill：将 skill body 注入当前对话上下文。
 *
 * 快速失败：如果 allowedTools 中有未注册的工具，抛出错误，
 * 不激活 skill 也不安装过滤器。在调用时而非执行中发现缺失依赖更好。
 */
export function runInline(
  skill: Skill,
  args: string,
  host: SkillHost
): string {
  // 先做依赖检查，失败时不会激活 skill
  assertAllowedToolsExist(skill, host);

  // 替换 body 中的 $ARGUMENTS 占位符；没有占位符时追加用户请求
  let body = skill.body;
  if (body.includes("$ARGUMENTS")) {
    body = body.replaceAll("$ARGUMENTS", args);
  } else if (args) {
    body += `\n\nUser Request: ${args}`;
  }

  host.activateSkill(skill.meta.name, body);

  // 安装工具白名单过滤器
  if (skill.meta.allowedTools) {
    const allowed = new Set(skill.meta.allowedTools);
    host.setToolFilter((name) => allowed.has(name));
  }

  return body;
}

/**
 * 以 fork 模式运行 skill：在隔离的子代理中执行。
 * 快速失败：同样在执行前检查 allowedTools 依赖。
 */
export async function runFork(
  skill: Skill,
  args: string,
  host: SkillForkHost
): Promise<string> {
  // 先做依赖检查
  assertAllowedToolsExist(skill, host);

  let prompt = skill.body;
  if (args) {
    prompt += `\n\nARGUMENTS: ${args}`;
  }

  // 根据 forkContext 配置决定携带多少父对话上下文
  const contextMode = skill.meta.forkContext ?? "none";
  if (contextMode === "recent") {
    const context = host.snapshotParentMessages(5);
    prompt = `Context from parent conversation:\n${context}\n\n${prompt}`;
  } else if (contextMode === "full") {
    const context = host.snapshotParentMessages(100);
    prompt = `Context from parent conversation:\n${context}\n\n${prompt}`;
  }

  return host.runSubAgent(prompt, skill.meta.allowedTools);
}
