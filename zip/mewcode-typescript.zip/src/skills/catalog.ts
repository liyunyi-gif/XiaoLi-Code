// 来源：公众号@小林coding
// 后端八股网站：xiaolincoding.com
// Agent网站：xiaolinnote.com
// 简历模版：jianli.xiaolinnote.com

import { readdirSync, readFileSync, existsSync, statSync } from "node:fs";
import { join } from "node:path";
import { homedir } from "node:os";
import yaml from "js-yaml";
import type { Skill, SkillMeta } from "./skill.js";

/** 内部存储的 skill 附带源文件路径和加载时间戳，用于热重载 */
interface CatalogEntry {
  skill: Skill;
  /** SKILL.md 的绝对路径，用于热重载时重新读取 */
  filePath: string;
  /** 上次加载时文件的修改时间（ms），0 表示内嵌 skill 无需重载 */
  loadedMtimeMs: number;
}

export class SkillCatalog {
  private entries = new Map<string, CatalogEntry>();

  load(workDir: string): void {
    // 先扫描用户目录，再扫描项目目录，项目 skill 可覆盖同名用户 skill
    const dirs = [
      join(homedir(), ".mewcode", "skills"),
      join(workDir, ".mewcode", "skills"),
    ];

    for (const dir of dirs) {
      if (!existsSync(dir)) continue;
      this.scanDirectory(dir);
    }
  }

  private scanDirectory(dir: string): void {
    let dirEntries: string[];
    try {
      dirEntries = readdirSync(dir);
    } catch {
      return;
    }

    for (const entry of dirEntries) {
      const fullPath = join(dir, entry);
      const stat = statSync(fullPath);

      if (stat.isDirectory()) {
        const skillFile = join(fullPath, "SKILL.md");
        if (existsSync(skillFile)) {
          this.loadSkill(skillFile, fullPath, true);
        }
      } else if (entry.endsWith(".md") && entry !== "SKILL.md") {
        this.loadSkill(fullPath, dir, false);
      }
    }
  }

  private loadSkill(filePath: string, sourceDir: string, isDirectory: boolean): void {
    try {
      const raw = readFileSync(filePath, "utf-8");
      const parsed = parseSkillFile(raw);
      if (!parsed) return;

      const skill: Skill = {
        meta: parsed.meta,
        body: parsed.body,
        sourceDir,
        isDirectory,
      };

      // 记录文件修改时间，用于后续热重载检测
      let mtimeMs = 0;
      try {
        mtimeMs = statSync(filePath).mtimeMs;
      } catch {
        // 无法获取时间戳时不影响加载
      }

      this.entries.set(skill.meta.name, {
        skill,
        filePath,
        loadedMtimeMs: mtimeMs,
      });
    } catch {
      // 跳过无效 skill
    }
  }

  list(): SkillMeta[] {
    return [...this.entries.values()].map((e) => e.skill.meta);
  }

  /**
   * 获取 skill，支持热重载：如果磁盘文件已被修改，自动重新读取。
   * 对齐 Go 版 GetFull：每次调用时重新读取 body（热重载），
   * 读取失败时保留已缓存的 body。
   */
  get(name: string): Skill | undefined {
    const entry = this.entries.get(name);
    if (!entry) return undefined;

    // 尝试热重载：检查文件是否已修改
    if (entry.filePath && entry.loadedMtimeMs > 0) {
      try {
        const currentMtime = statSync(entry.filePath).mtimeMs;
        if (currentMtime > entry.loadedMtimeMs) {
          // 文件已修改，重新读取
          const raw = readFileSync(entry.filePath, "utf-8");
          const parsed = parseSkillFile(raw);
          if (parsed) {
            entry.skill = {
              meta: parsed.meta,
              body: parsed.body,
              sourceDir: entry.skill.sourceDir,
              isDirectory: entry.skill.isDirectory,
            };
            entry.loadedMtimeMs = currentMtime;
          }
          // 解析失败时保留已缓存版本（与 Go 行为一致）
        }
      } catch {
        // 读取失败时保留已缓存版本
      }
    }

    return entry.skill;
  }

  has(name: string): boolean {
    return this.entries.has(name);
  }
}

function parseSkillFile(
  content: string
): { meta: SkillMeta; body: string } | null {
  if (!content.startsWith("---")) return null;

  const endIdx = content.indexOf("---", 3);
  if (endIdx === -1) return null;

  const frontmatter = content.slice(3, endIdx).trim();
  const body = content.slice(endIdx + 3).trim();

  try {
    const raw = yaml.load(frontmatter) as Record<string, unknown> | null;
    if (!raw?.name) return null;

    return {
      meta: {
        name: raw.name as string,
        description: (raw.description as string) ?? "",
        allowedTools: raw.allowed_tools as string[] | undefined,
        mode: (raw.mode as "inline" | "fork") ?? "inline",
        model: raw.model as string | undefined,
        forkContext: raw.fork_context as "full" | "recent" | "none" | undefined,
      },
      body,
    };
  } catch {
    return null;
  }
}
